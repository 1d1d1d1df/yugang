#include <stdio.h>
#include <unistd.h>

#include "ohos_init.h"
#include "cmsis_os2.h"

#include "hi_gpio.h"
#include "hi_io.h"
#include "hi_adc.h"
#include "hi_errno.h"
#include "iot_gpio.h"

#define STACK_SIZE   (1024)
#define DELAY_US     (2000000)

int guang = 0;

static void AdcGpioTask(void)
{
    IoTGpioInit(7);
    IoTGpioSetDir(7, IOT_GPIO_DIR_OUT);//GPIO7

    static int count = 1000;
    hi_u16 value;
    while (count--) {
        if (hi_adc_read(HI_ADC_CHANNEL_2, &value,HI_ADC_EQU_MODEL_2, HI_ADC_CUR_BAIS_DEFAULT, 0) != HI_ERR_SUCCESS) {
            printf("ADC read error!\n");
        } else {
            printf("b=%u\n", (unsigned int)value);
            usleep(DELAY_US);
            guang = value;
            if(guang > 1500)
            {
                IoTGpioSetOutputVal(7, IOT_GPIO_VALUE1); // 如果当前是熄灭，则点亮
                printf("guangzhao ok2\n");
            }
            else
            {
                usleep(DELAY_US);
                usleep(DELAY_US);
                IoTGpioSetOutputVal(7, IOT_GPIO_VALUE0);
                printf("guangzhao close2\n");
            }
        }
    }
}

static void AdcGpioEntry(void)
{
    printf("ADC Test!\n");
    osThreadAttr_t attr;

    hi_gpio_init();
    hi_io_set_func(HI_GPIO_IDX_9, HI_IO_FUNC_GPIO_9_GPIO);
    hi_gpio_set_dir(HI_GPIO_IDX_9, HI_GPIO_DIR_IN);

    attr.name = "AdcGpioTask";
    attr.attr_bits = 0U;
    attr.cb_mem = NULL;
    attr.cb_size = 0U;
    attr.stack_mem = NULL;
    attr.stack_size = STACK_SIZE;
    attr.priority = osPriorityNormal;

    if (osThreadNew(AdcGpioTask, NULL, &attr) == NULL) {
        printf("[LedExample] Falied to create LedTask!\n");
    }
}
SYS_RUN(AdcGpioEntry);