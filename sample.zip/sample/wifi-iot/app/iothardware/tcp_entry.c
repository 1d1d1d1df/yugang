#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include "ohos_init.h"
#include "cmsis_os2.h"
#include "hi_wifi_api.h"
#include "lwip/ip_addr.h"
#include "lwip/netifapi.h"
#include "lwip/sockets.h"
#include "hi_gpio.h"
#include "hi_io.h"
#include "hi_adc.h"
#include "hi_errno.h"
#include "aht20.h"
#include "global.h"
#include "iot_gpio.h"

#include "iot_gpio_ex.h"

#define STACK_SIZE   (1024)
#define DELAY_US     (1000000) // 设置为1秒
#define LED 7 //控制小灯的
#define HAT 0 //加热
#define huanshui 1 //换水
#define yangqi 10 //加氧气
#define guolv 8//过滤

static int fish_food = 0; //标记：0是未加食物，1是加食物

static unsigned short int servport = 3861; 
static char *servIP = "172.20.10.3";
//static char *servIP = "192.168.169.59";

//static unsigned short int servport = 3861;
//static char *servIP = "192.168.224.5";

static int sockfd = -1;
static int connfd = -1;
static osMutexId_t sendMutex; //发送数据的互斥锁,防止一个时间发送多个数据

//加食物——控制舵机
void SendSetAngleData(unsigned int duty)
{
    unsigned int time = 20000;

    IoTGpioSetOutputVal(IOT_IO_NAME_GPIO_2, IOT_GPIO_VALUE1);
    usleep(duty);
    IoTGpioSetOutputVal(IOT_IO_NAME_GPIO_2, IOT_GPIO_VALUE0);
    usleep(time - duty);
}

void middle_demo(void) //居中
{
    unsigned int angle = 1500;
    for (int i = 0; i < 10; i++) {
        SetAngle(angle);
    }
}

void dextroversion_demo(void) //右转90
{
    unsigned int angle = 500;
    for (int i = 0; i < 10; i++) {
        SetAngle(angle);
    }
}

void Left_demo(void) //左转90
{
    unsigned int angle = 2500;
    for (int i = 0; i < 10; i++) {
        SetAngle(angle);
    }
}

//定义舵机引脚
void Angle_Init(void)
{
    IoTGpioInit(IOT_IO_NAME_GPIO_2);
    IoSetFunc(IOT_IO_NAME_GPIO_2, IOT_IO_FUNC_GPIO_2_GPIO);
    IoTGpioSetDir(IOT_IO_NAME_GPIO_2, IOT_GPIO_DIR_OUT);
}

//执行操作
void SendAngleData(void)
{
    unsigned int time = 200;
    S92RInit();
        
    while (fish_food == 1) 
    {
        printf("Add food......\r\n");

        RegressMiddle();
        TaskMsleep(time);

        EngineTurnLeft();
        TaskMsleep(time);

        RegressMiddle();
        TaskMsleep(time);

        EngineTurnRight();
        TaskMsleep(time);

        RegressMiddle();
        TaskMsleep(time);

        RegressMiddle();
        TaskMsleep(time);

        EngineTurnLeft();
        TaskMsleep(time);

        RegressMiddle();
        TaskMsleep(time);

        EngineTurnRight();
        TaskMsleep(time);

        RegressMiddle();
        TaskMsleep(time);

        RegressMiddle();
        TaskMsleep(time);

        EngineTurnLeft();
        TaskMsleep(time);

        RegressMiddle();
        TaskMsleep(time);

        EngineTurnRight();
        TaskMsleep(time);

        RegressMiddle();
        TaskMsleep(time);
        
        printf("food close\r\n");
        //完成加食物一次，多整点，呵呵
        fish_food = 0;
    }
}
// 初始化控件中的引脚
static void InitGpio11(void)
{
    IoTGpioInit(LED);
    IoTGpioSetDir(LED, IOT_GPIO_DIR_OUT);//GPIO11

    IoTGpioInit(HAT);
    IoTGpioSetDir(HAT, IOT_GPIO_DIR_OUT);//GPIO0

    IoTGpioInit(huanshui);
    IoTGpioSetDir(huanshui, IOT_GPIO_DIR_OUT);//GPIO1

    IoTGpioInit(yangqi);
    IoTGpioSetDir(yangqi, IOT_GPIO_DIR_OUT);//GPIO10

    IoTGpioInit(guolv);
    IoTGpioSetDir(guolv, IOT_GPIO_DIR_OUT);//GPIO3

    printf("initialized OK.\n");
}

// 设置GPIO11状态
/*static void SetGpio11(int state)
{
    hi_gpio_set_output_val(HI_GPIO_IDX_11, state);
}*/


// 切换小灯的状态
static void ToggleGpio11(void)
{
    IotGpioValue value = IOT_GPIO_VALUE0;
    IoTGpioGetInputVal(LED, &value); // 获取当前GPIO的状态

    // 根据当前状态切换GPIO的输出值
    if (value == IOT_GPIO_VALUE0) {
        IoTGpioSetOutputVal(LED, IOT_GPIO_VALUE1); // 如果当前是熄灭，则点亮
        printf("led ok\n");
    } else {
        IoTGpioSetOutputVal(LED, IOT_GPIO_VALUE0); // 如果当前是点亮，则熄灭
        printf("led close\n");
    }
}

//换水
static void ToggleGpio1(void)
{
    IotGpioValue value = IOT_GPIO_VALUE0;
    IoTGpioGetInputVal(huanshui, &value); // 获取当前GPIO的状态
    
    // 根据当前状态切换GPIO的输出值
    if (value == IOT_GPIO_VALUE0) {
        IoTGpioSetOutputVal(huanshui, IOT_GPIO_VALUE1); // 如果当前是熄灭，则点亮
        printf("huanshui ok\n");
    } else {
        IoTGpioSetOutputVal(huanshui, IOT_GPIO_VALUE0); // 如果当前是点亮，则熄灭
        printf("huanshui close\n");
    }
}

//过滤
static void ToggleGpio3(void)
{
    IotGpioValue value = IOT_GPIO_VALUE0;
    IoTGpioGetInputVal(guolv, &value); // 获取当前GPIO的状态
    
    // 根据当前状态切换GPIO的输出值
    if (value == IOT_GPIO_VALUE0) {
        IoTGpioSetOutputVal(guolv, IOT_GPIO_VALUE1); // 如果当前是熄灭，则点亮
        printf("guolv ok\n");
    } else {
        IoTGpioSetOutputVal(guolv, IOT_GPIO_VALUE0); // 如果当前是点亮，则熄灭
        printf("guolv close\n");
    }
}

//氧气
static void ToggleGpio10(void)
{
    IotGpioValue value = IOT_GPIO_VALUE0;
    IoTGpioGetInputVal(yangqi, &value); // 获取当前GPIO的状态

    // 根据当前状态切换GPIO的输出值
    if (value == IOT_GPIO_VALUE0) {
        IoTGpioSetOutputVal(yangqi, IOT_GPIO_VALUE1); // 如果当前是熄灭，则点亮
        printf("yangqi ok\n");
    } else {
        IoTGpioSetOutputVal(yangqi, IOT_GPIO_VALUE0); // 如果当前是点亮，则熄灭
        printf("yangqi close\n");
    }
}

//切换加热的状态
static void ToggleGpio0(void)
{
    IotGpioValue value = IOT_GPIO_VALUE0;
    IoTGpioGetInputVal(HAT, &value); // 获取当前GPIO的状态

    // 根据当前状态切换GPIO的输出值
    if (value == IOT_GPIO_VALUE0) {
        IoTGpioSetOutputVal(HAT, IOT_GPIO_VALUE1); // 如果当前是关的，则加热
        printf("HAO ok\n");
    } else {
        IoTGpioSetOutputVal(HAT, IOT_GPIO_VALUE0); // 如果当前是加热，则关掉
        printf("HAO close\n");
    }
}



// 浑浊度
static void SendTurbidityData(int sockfd)
{
    hi_u16 value;
    char send_buff[64] = {0};

    if (hi_adc_read(HI_ADC_CHANNEL_4, &value, HI_ADC_EQU_MODEL_4, HI_ADC_CUR_BAIS_DEFAULT, 0) != HI_ERR_SUCCESS) {
        printf("ADC read error!\n");
    } else {
        snprintf(send_buff, sizeof(send_buff), "a=%u\n", (unsigned int)value);
        osMutexAcquire(sendMutex, osWaitForever);
        int bytes_sent = send(sockfd, send_buff, strlen(send_buff), 0);
        osMutexRelease(sendMutex);
        if (bytes_sent < 0) {
            printf("Failed to send turbidity data: %s\n", strerror(errno));
        } else {
            printf("Successfully sent turbidity data: %s\n", send_buff);
        }
    }
}

// 光照强度
static void SendLightData(int sockfd)
{
    hi_u16 value;
    char send_buff[64] = {0};

    if (hi_adc_read(HI_ADC_CHANNEL_2, &value, HI_ADC_EQU_MODEL_2, HI_ADC_CUR_BAIS_DEFAULT, 0) != HI_ERR_SUCCESS) {
        printf("ADC read error!\n");
    } else {
        snprintf(send_buff, sizeof(send_buff), "b=%u\n", (unsigned int)value);
        osMutexAcquire(sendMutex, osWaitForever);
        int bytes_sent = send(sockfd, send_buff, strlen(send_buff), 0);
        osMutexRelease(sendMutex);
        if (bytes_sent < 0) {
            printf("Failed to send light data: %s\n", strerror(errno));
        } else {
            printf("Successfully sent light data: %s\n", send_buff);
        }
    }
}

// 温度
static void SendTemperatureData(int sockfd)
{
    char send_buff[64] = {0};
    snprintf(send_buff, sizeof(send_buff), "c=%.2f\n", last_known_temp);
    osMutexAcquire(sendMutex, osWaitForever);
    if (send(sockfd, send_buff, strlen(send_buff), 0) < 0) {
        printf("Failed to send temperature data: %s\n", strerror(errno));
    } else {
        printf("Successfully sent temperature data: %s\n", send_buff);
    }
    osMutexRelease(sendMutex);
}

//主函数
void TcpClientTask(void)
{
    int ret;
    unsigned char recv_buff[64] = { 0 };

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        printf("Failed to create socket: %s\n", strerror(errno));
        return;
    }

    struct sockaddr_in serverAddr = {0};
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(servport);
    inet_pton(AF_INET, servIP, &serverAddr.sin_addr);

    while (1) {
        connfd = connect(sockfd, (struct sockaddr *)&serverAddr, sizeof(serverAddr));
        if (connfd != 0) {
            printf("Connect failed, retrying...\n");
            close(sockfd);
            sleep(1);
            sockfd = socket(AF_INET, SOCK_STREAM, 0);
            continue;
        }

        printf("Connected to server.\n");

        while (1) {
            SendTurbidityData(sockfd);   // 发送浑浊度数据   a
            usleep(1500000);      //增加延迟，防止一顿数据发出去，不行就往高的调
            SendLightData(sockfd);       // 发送光照数据    b
            usleep(1500000);       
            SendTemperatureData(sockfd); // 发送温度数据    c
            usleep(1500000);      
            
            // 检查连接状态
            ret = recv(sockfd, &recv_buff, sizeof(recv_buff), MSG_DONTWAIT);
            if (ret < 0 && errno != EWOULDBLOCK) {
                printf("Connection lost or error occurred: %s\n", strerror(errno));
                close(sockfd);
                sockfd = socket(AF_INET, SOCK_STREAM, 0);
                break;
            }
            else if(ret > 0)
            {
                printf("Received data: %s\n", recv_buff); // 输出接收到的数据
                //处理接收到的数据
                for(int i = 0;i < ret;i ++)
                {
                    if(recv_buff[i] == 'A')//开关灯
                    {
                        printf("Received 'A', toggling GPIO11\n");
                        ToggleGpio11();//切换状态
                    }
                     if(recv_buff[i] == 'B')//加热
                    {
                        printf("Received 'B', toggling GPIO0\n");
                        ToggleGpio0();//切换状态
                    }
                    if(recv_buff[i] == 'E')//加食物
                    {
                        printf("Received 'E', toggling GPIO0\n");
                        if(fish_food == 0)
                        {
                            fish_food = 1;
                            SendAngleData();//切换状态
                            printf("food ok\r\n");
                        }
                    }
                    if(recv_buff[i] == 'D')//加食物
                    {
                        ToggleGpio1();
                        printf("huanshui ok\r\n");
                    }
                    if(recv_buff[i] == 'C')//加氧气
                    {
                        ToggleGpio10();
                        printf("yangqi ok\r\n");
                    }
                    if(recv_buff[i] == 'F')//过滤
                    {
                        ToggleGpio3();
                        printf("guolv ok\r\n");

                    }
                }
            }
        }
        close(sockfd);
    }
}

void TcpClientEntry(void)
{
    osThreadAttr_t attr1 = {"TcpClientTask", 0, NULL, 0, NULL, 1024*4, 32, 0, 0};
    sendMutex = osMutexNew(NULL);
    InitGpio11(); // 初始化控件的引脚
    Angle_Init();
    if (osThreadNew((osThreadFunc_t)TcpClientTask, NULL, &attr1) == NULL) {
        printf("Failed to create TcpClientTask!\n");
    }
}