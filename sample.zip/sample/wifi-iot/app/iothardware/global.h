#ifndef GLOBAL_H
#define GLOBAL_H

extern float last_known_temp;  // 声明为外部变量，供其他文件访问
extern int shui; 

#endif // GLOBAL_H