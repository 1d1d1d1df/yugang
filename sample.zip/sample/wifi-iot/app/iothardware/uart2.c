#include <stdio.h>
#include <unistd.h>

#include "ohos_init.h"
#include "cmsis_os2.h"

#include "hi_gpio.h"
#include "hi_io.h"
#include "hi_adc.h"
#include "hi_errno.h"
#include "hi_i2c.h"
#include "iot_uart.h"
#include "iot_gpio.h"

#include "iot_gpio_ex.h"

#define STACK_SIZE       (1024)
#define AHT20_STACK_SIZE (4096)
#define UART_STACK_SIZE  (1024)
#define DELAY_US         (100000)
#define DELAY_S          (1)
#define I2C_DATA_RATE    (400 * 1000)  // 400K
#define IOT_GPIO_hun     (7)
#define IOT_UART_IDX_2   (2)
#define IOT_GPIO_11      (11)
#define IOT_GPIO_12      (12)
#define IOT_GPIO_led     (0)

unsigned char uartWriteBuff[] = "uart_led ok";
unsigned char uartReadBuff[2048] = {0};

static int fish = 0; //标记：0是未加食物，1是加食物

int usr_uart_config(void)
{
    IotUartAttribute g_uart_cfg = {115200, 8, 1, IOT_UART_PARITY_NONE, 500, 500, 0};
    int ret = IoTUartInit(IOT_UART_IDX_2, &g_uart_cfg);
    if (ret != 0) {
        //printf("uart init fail\r\n");
    }
    return ret;
}

//定义舵机引脚
void Angle_Init_demo(void)
{
    IoTGpioInit(IOT_IO_NAME_GPIO_2);
    IoSetFunc(IOT_IO_NAME_GPIO_2, IOT_IO_FUNC_GPIO_2_GPIO);
    IoTGpioSetDir(IOT_IO_NAME_GPIO_2, IOT_GPIO_DIR_OUT);
}

//执行操作
void SendAngleData_demo(void)
{
    unsigned int time = 200;
    S92RInit();
        
    while (fish == 1) 
    {
        printf("Add food......\r\n");

        RegressMiddle();
        TaskMsleep(time);

        EngineTurnLeft();
        TaskMsleep(time);

        RegressMiddle();
        TaskMsleep(time);

        EngineTurnRight();
        TaskMsleep(time);

        RegressMiddle();
        TaskMsleep(time);

        RegressMiddle();
        TaskMsleep(time);

        EngineTurnLeft();
        TaskMsleep(time);

        RegressMiddle();
        TaskMsleep(time);

        EngineTurnRight();
        TaskMsleep(time);

        RegressMiddle();
        TaskMsleep(time);

        RegressMiddle();
        TaskMsleep(time);

        EngineTurnLeft();
        TaskMsleep(time);

        RegressMiddle();
        TaskMsleep(time);

        EngineTurnRight();
        TaskMsleep(time);

        RegressMiddle();
        TaskMsleep(time);
        
        fish = 0;
        printf("food close\r\n");
        //完成加食物一次，多整点，呵呵
    }
}
// 初始化控件中的引脚
static void InitGpio1_Demo(void)
{
    IoTGpioInit(0);
    IoTGpioSetDir(0, IOT_GPIO_DIR_OUT);//GPIO0

    IoTGpioInit(7);
    IoTGpioSetDir(7, IOT_GPIO_DIR_OUT);//GPIO7

    IoTGpioInit(10);
    IoTGpioSetDir(10, IOT_GPIO_DIR_OUT);//GPIO10

    IoTGpioInit(1);
    IoTGpioSetDir(1, IOT_GPIO_DIR_OUT);//GPIO1

    IoTGpioInit(8);
    IoTGpioSetDir(8, IOT_GPIO_DIR_OUT);//GPIO8

    printf("initialized OK.\n");
}

void UartDemo_Task(void *argument)
{
    static int count = 1000;

    IoTGpioInit(IOT_GPIO_11);
    IoTGpioInit(IOT_GPIO_12);

    hi_io_set_func(IOT_GPIO_11, HI_IO_FUNC_GPIO_11_UART2_TXD);
    hi_io_set_func(IOT_GPIO_12, HI_IO_FUNC_GPIO_12_UART2_RXD);


    usr_uart_config();

    int ret = IoTUartWrite(2, (unsigned char *)uartWriteBuff, sizeof(uartWriteBuff));
    printf("Uart Write data: ret = %d\r\n", ret);
    while (count--) {
        unsigned int len = IoTUartRead(2, uartReadBuff, sizeof(uartReadBuff));
        if (len > 0) 
        {
            uartReadBuff[len] = '\0';
            printf("Uart read data: %s\r\n", uartReadBuff);
            //  灯
            if (uartReadBuff[0] == '1') //开灯
            {
                IoTGpioSetOutputVal(7, 1);
                printf("led ok");
            }
            if(uartReadBuff[0] == '2') //关灯
            {
                IoTGpioSetOutputVal(7, 0);
                printf("led close");
            }
            // 加热
            if(uartReadBuff[0] == '3') //开启加热
            {
                IoTGpioSetOutputVal(0, 1);
                printf("jiare ok");
            }
            if(uartReadBuff[0] == '4') //关闭加热
            {
                IoTGpioSetOutputVal(0, 0);
                printf("jiare close");
            }
            // 氧气
            if(uartReadBuff[0] == '5') //开启制氧气
            {
                IoTGpioSetOutputVal(10, 1);
                printf("yangqi ok");
            }
            if(uartReadBuff[0] == '6') //关闭制氧气
            {
                IoTGpioSetOutputVal(10, 0);
                printf("yangqi close");
            }
            //换水
            if(uartReadBuff[0] == '7') //开启换水
            {
                IoTGpioSetOutputVal(1, 1);
                printf("huanshui ok");
            }
            if(uartReadBuff[0] == '8') //关闭换水
            {
                IoTGpioSetOutputVal(1, 0);
                printf("huanshui close");
            }
            //加食物
            if(uartReadBuff[0] == '9') 
            {
                fish = 1;
                SendAngleData_demo();
                printf("jiashiwu ok");
            }
            //过滤
            if(uartReadBuff[0] == 'k') //开启
            {
                IoTGpioSetOutputVal(8, 1);
                printf("golv ok");
            }
            if(uartReadBuff[0] == 't') //关闭
            {
                IoTGpioSetOutputVal(8, 0);
                printf("golv close");
            }
        }
        usleep(DELAY_US);
    }
}

static void CombinedEntry(void)
{
    printf("Combined Program Entry!\n");
    osThreadAttr_t attr = {
        .name = "AdcGpioTask",
        .attr_bits = 0U,
        .cb_mem = NULL,
        .cb_size = 0U,
        .stack_mem = NULL,
        .stack_size = STACK_SIZE,
        .priority = osPriorityNormal,
    };
    Angle_Init_demo();
    InitGpio1_Demo();
    attr.name = "UartDemo_Task";
    attr.stack_size = UART_STACK_SIZE;
    if (osThreadNew(UartDemo_Task, NULL, &attr) == NULL) {
        printf("Failed to create UartDemo_Task!\n");
    }
}

SYS_RUN(CombinedEntry);