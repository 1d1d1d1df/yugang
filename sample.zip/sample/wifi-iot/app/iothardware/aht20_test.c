#include "aht20.h"
#include <stdio.h>
#include <unistd.h>
#include "ohos_init.h"
#include "cmsis_os2.h"
#include "hi_gpio.h"
#include "hi_io.h"
#include "hi_i2c.h"

#define STACK_SIZE     (4096)
#define I2C_DATA_RATE  (400 * 1000)  // 400K
#define DELAY_S        (2)
#define RETRY_LIMIT    (5)

#include "global.h"

float last_known_temp = 0.0;  // 初始化并定义这个变量

void Aht20TestTask(void)
{
    static int count = 1000;
    uint32_t retval = 0;

    hi_io_set_func(HI_IO_NAME_GPIO_13, HI_IO_FUNC_GPIO_13_I2C0_SDA);
    hi_io_set_func(HI_IO_NAME_GPIO_14, HI_IO_FUNC_GPIO_14_I2C0_SCL);

    hi_i2c_init(HI_I2C_IDX_0, I2C_DATA_RATE);

    retval = AHT20_Calibrate();
    printf("AHT20_Calibrate: %u\r\n", retval);

    while (count--) {
        float temp = 0.0, humi = 0.0;

        retval = AHT20_StartMeasure();
        if (retval == 0) {
            retval = AHT20_GetMeasureResult(&temp, &humi);
            if (retval == 0) {
                last_known_temp = temp;  // 更新最后一次成功读取的温度
                printf("c=%.2f\n", temp);
            }
        }
        sleep(DELAY_S);
    }
}

void Aht20Test(void)
{
    osThreadAttr_t attr;

    attr.name = "Aht20Task";
    attr.attr_bits = 0U;
    attr.cb_mem = NULL;
    attr.cb_size = 0U;
    attr.stack_mem = NULL;
    attr.stack_size = STACK_SIZE;
    attr.priority = osPriorityNormal;

    if (osThreadNew(Aht20TestTask, NULL, &attr) == NULL) {
        printf("[Aht20Test] Failed to create Aht20TestTask!\n");
    }
}
APP_FEATURE_INIT(Aht20Test);