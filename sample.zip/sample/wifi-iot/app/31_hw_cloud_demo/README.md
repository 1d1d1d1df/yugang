**注意：**

31_hw_cloud_demo 和 32_hw_cloud_demo 两个示例程序，实现的功能是一模一样的，稍微有点区别的地方在于：

> 31_hw_cloud_demo 所使用的 libiot_link.a 库，是预编译的；
>
> 32_hw_cloud_demo 则是直接使用 源代码编译出 libiot_link.a。libiot_link.a 库 的源代码，见：[这里](https://gitee.com/openharmony-sig/knowledge_demo_smart_home/tree/master/dev/third_party/iot_link)
