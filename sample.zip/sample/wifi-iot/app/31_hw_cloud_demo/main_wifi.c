#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>

#include "ohos_init.h"
#include "cmsis_os2.h"
#include "iot_i2c.h"
#include "iot_gpio.h"
#include "iot_pwm.h"
#include "iot_uart.h"
#include "iot_errno.h"

#include <hi_pwm.h>
#include <hi_gpio.h>
#include <hi_io.h>
#include <hi_adc.h>
#include <hi_watchdog.h>

#include "aht20.h"

#define DELAY_US     (2000000)

float g_Temp = 0.0;    // 温度
float g_Humi = 0.0;    // 湿度
int g_hun = 0;//浑浊度
int g_guangzhao = 0;//光照
char Temp_string[5];


#define I2C0_IDX      (0)
#define I2C0_BAUDRATE (400*1000)
static int I2C0Init(void)
{
    IoTGpioInit(HI_IO_NAME_GPIO_13);
    IoTGpioInit(HI_IO_NAME_GPIO_14);
    hi_io_set_func(HI_IO_NAME_GPIO_13, HI_IO_FUNC_GPIO_13_I2C0_SDA);
    hi_io_set_func(HI_IO_NAME_GPIO_14, HI_IO_FUNC_GPIO_14_I2C0_SCL);

    return IoTI2cInit(I2C0_IDX, I2C0_BAUDRATE);
}
static void I2C0DeInit(void)
{
    IoTI2cDeinit(I2C0_IDX);
}

void MainTask_aaa(void)
{
    int ret = -1;
    hi_watchdog_disable();

    if (I2C0Init() != 0) {
        return;
    }

    // 初始化ADC和GPIO
    hi_gpio_init();
    hi_io_set_func(HI_GPIO_IDX_5, HI_IO_FUNC_GPIO_5_GPIO);
    hi_gpio_set_dir(HI_GPIO_IDX_5, HI_GPIO_DIR_IN);
    hi_io_set_func(HI_GPIO_IDX_9, HI_IO_FUNC_GPIO_9_GPIO);
    hi_gpio_set_dir(HI_GPIO_IDX_9, HI_GPIO_DIR_IN);

    WifiTask_ccc();
    huawei_cloud_mqtt_init();

    ret = AHT20_ddd();
    printf("[MainTask] AHT20_ddd: ret[%d]\n", ret);

    while (1) {
        sleep(1);
        ret = AHT20_eee();
        printf("[MainTask] AHT20_eee: ret[%d]\n", ret);

        ret = AHT20_fff(&g_Temp, &g_Humi);
        printf("[MainTask] AHT20_fff: ret[%d], Temp[%.2f], Humi[%.2f]\n",
               ret, g_Temp, g_Humi);

        sprintf(Temp_string,"%.2f",g_Temp);
        

        //光照
        if (hi_adc_read(HI_ADC_CHANNEL_2, &g_guangzhao,HI_ADC_EQU_MODEL_2, HI_ADC_CUR_BAIS_DEFAULT, 0) != HI_ERR_SUCCESS) {
            printf("guangzhao read error!\n");
        } else {
            printf("guangzhao=%u\n", (unsigned int)g_guangzhao);
            usleep(DELAY_US);
        }
        //浑浊度
        if (hi_adc_read(HI_ADC_CHANNEL_4, &g_hun, HI_ADC_EQU_MODEL_4, HI_ADC_CUR_BAIS_DEFAULT, 0) != HI_ERR_SUCCESS) {
            printf("hun read error!\n");
        } else {
            printf("hun=%u\n", (unsigned int)g_hun);
            usleep(DELAY_US);
        }

        deal_report_msg();  // send to huawei cloud
    }

    I2C0DeInit();
}

void MainEntry_aaa(void)
{

    osThreadAttr_t attr = {"MainTask", 0, NULL, 0, NULL, 1024*10, 24, 0, 0};

    if (osThreadNew((osThreadFunc_t)MainTask_aaa, NULL, &attr) == NULL) {
        printf("[MainEntry] create MainTask Failed!\n");
    }
}
SYS_RUN(MainEntry_aaa);